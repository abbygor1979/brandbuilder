<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SessionName extends Model
{
    protected $fillable = ['session_id', 'name'];
}